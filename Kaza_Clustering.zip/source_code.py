import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
from scipy.spatial.distance import cdist
from sklearn.metrics import silhouette_samples
import matplotlib.cm as cm

# Read in data - remove first line
PATH = "C:\\Users\\pkk503\\Documents\\Clustering\\data.txt"
medicare = pd.read_csv(PATH,sep = '\t')
medicare.drop(medicare.index[0],inplace=True)
medicare = medicare.reset_index(drop = True)
print(medicare.head())

## DATA EXPLORATION ##
# Plot histograms of numerical features for data exploration
plt.hist(medicare.line_srvc_cnt,bins = 50, range = (0.0,600.0))
plt.hist(medicare.bene_unique_cnt,bins = 50, range = (0.0,400.0))
plt.hist(medicare.bene_day_srvc_cnt,bins = 50, range = (0.0,400.0))
plt.hist(medicare.average_Medicare_allowed_amt,bins = 40, range = (0.0,500.0))
plt.hist(medicare.average_submitted_chrg_amt,bins = 40, range = (0.0,1000.0))
plt.hist(medicare.average_Medicare_payment_amt,bins = 40, range = (0.0,400.0))

# Obtain standard summaries of each feature for data exploration
medicare.describe()

# Perform bivariate analysis between various features for data exploration
plt.scatter(medicare.average_submitted_chrg_amt,medicare.average_Medicare_payment_amt)
np.corrcoef(medicare.average_submitted_chrg_amt,medicare.average_Medicare_payment_amt)

np.corrcoef(medicare.average_Medicare_allowed_amt,medicare.average_Medicare_payment_amt)
plt.scatter(medicare.average_Medicare_allowed_amt,medicare.average_Medicare_payment_amt)

np.corrcoef(medicare.average_Medicare_standard_amt,medicare.average_Medicare_payment_amt)
plt.scatter(medicare.average_Medicare_standard_amt,medicare.average_Medicare_payment_amt)

np.corrcoef(medicare.line_srvc_cnt,medicare.average_Medicare_payment_amt)
plt.scatter(medicare.line_srvc_cnt,medicare.average_Medicare_payment_amt)
plt.scatter(medicare.line_srvc_cnt,medicare.average_Medicare_allowed_amt)
plt.scatter(medicare.line_srvc_cnt,medicare.average_submitted_chrg_amt)

medicare[(medicare['nppes_provider_country'] == 'US')].count()

# Create feature for total amount that Medicare paid for each record (average payment * total # services)
medicare['total_medicare_pmt'] = medicare['line_srvc_cnt']*medicare['average_Medicare_payment_amt']
plt.hist(medicare.total_medicare_pmt,bins = 50, range = (0.0,20000.0))

# More bivariate analysis
plt.scatter(medicare.line_srvc_cnt,medicare.total_medicare_pmt)
plt.scatter(medicare.bene_unique_cnt,medicare.total_medicare_pmt)

# Explore various features to determine viability as features
print(medicare.groupby(['hcpcs_code']).size()) # 
print(medicare.groupby(['place_of_service']).size()) # Comparable number of facilities and offices
print(medicare.groupby(['medicare_participation_indicator']).size()) # Not enough data of non-participants to use as feature
print(medicare.groupby(['provider_type']).size())

# 2-way table for data exploration
test1 = medicare.groupby(['place_of_service','nppes_entity_code'])
test1.size()

# List all specialties and determine radiology-specific specialties
print(medicare.groupby(['provider_type']).size())
print(medicare.groupby(['provider_type']).size()[30:61])


# After problem has been identified and features have been chosen
# Features: US Regions, Revenue of Radiologists


data_0 = medicare[(medicare['provider_type'] == 'Diagnostic Radiology')]
data_1 = medicare[(medicare['provider_type'] == 'Interventional Radiology')]
data = pd.concat([data_0,data_1])
data = data[['nppes_provider_country','nppes_provider_zip','average_Medicare_allowed_amt','line_srvc_cnt']].copy()
data = data[(data['nppes_provider_country'] == 'US')]
del data['nppes_provider_country']
del data_0
del data_1
data['revenue'] = data['line_srvc_cnt']*data['average_Medicare_allowed_amt']
del data['line_srvc_cnt']
del data['average_Medicare_allowed_amt']
data = data.reset_index(drop = True)
del medicare


data['zip_1dig'] = data['nppes_provider_zip'].astype(str).str[0:1]
data['zip_1dig'] = data['zip_1dig'].astype(int)
plt.hist(data.revenue,bins = 40,range = (0.0,3000000))
plt.hist(data.revenue,bins = 40,range = (0.0,30000))
plt.xlabel('Average Revenue per Service')
plt.ylabel('Frequency')

data = data.reset_index(drop = True)


zip_bin = []
for ii in range(0,len(data)):
    if ((data.zip_1dig[ii] == 9) or (data.zip_1dig[ii] == 8)):
        zip_bin.append('West')
    elif ((data.zip_1dig[ii] == 4) or (data.zip_1dig[ii] == 5) or (data.zip_1dig[ii] == 6)):
        zip_bin.append('Midwest')
    elif ((data.zip_1dig[ii] == 0) or (data.zip_1dig[ii] == 1) or (data.zip_1dig[ii] == 2)):
        zip_bin.append('Northeast')
    else:
        zip_bin.append('South')

zip_bin = pd.DataFrame(data = zip_bin,index = range(0,len(zip_bin)),columns = ['zip_bin'])
data = pd.concat([data,zip_bin],axis = 1)
del zip_bin
del data['zip_1dig']
del data['nppes_provider_zip']

label_encoder = LabelEncoder()
onehot_encoder = OneHotEncoder(sparse = False)
region_integer_encoded = label_encoder.fit_transform(data['zip_bin'])
region_integer_encoded = region_integer_encoded.reshape(len(region_integer_encoded), 1)
region_onehot_encoded = onehot_encoder.fit_transform(region_integer_encoded)
region = pd.DataFrame(data = region_onehot_encoded,index = range(0,len(data)),columns = ['Midwest','Northeast','South','West'])
data = pd.concat([data,region],axis = 1)
del region
del region_integer_encoded
del region_onehot_encoded
del data['zip_bin']

plt.hist(data['revenue'],bins = 40,range = (0.0,12000.0),log = False)        
plt.hist(data['revenue'],bins = 40,range = (0.0,12000.0),log = True)        

data['log_revenue'] = np.log(data['revenue'])
plt.hist(data['log_revenue'],bins = 50,range = (0.0,20),log = False)

del data['revenue']

# Scaling
minimum = min(data['log_revenue'])
maximum = max(data['log_revenue'])

min_max_scaler = MinMaxScaler()
data_minmax = min_max_scaler.fit_transform(data)
plt.hist(data['log_revenue'],bins = 30)
plt.xlabel('Average Revenue per Service Transformed and Standardized')
plt.ylabel('Frequency')

# K-Means determine k
distortions = []
K = range(1,8)
for k in K:
    kmeanModel = KMeans(n_clusters=k).fit(data_minmax)
    kmeanModel.fit(data_minmax)
    distortions.append(sum(np.min(cdist(data_minmax, kmeanModel.cluster_centers_, 'euclidean'), axis=1)) / data_minmax.shape[0])

# Create Scree Plot
plt.plot(K, distortions, 'bx-')
plt.xlabel('k')
plt.ylabel('Distortion')
plt.title('Scree Plot for Optimal k')
plt.show()

# Run K-Means
k = 4
kmeans = KMeans(n_clusters = k)
labels = kmeans.fit_predict(data_minmax)
centroids = kmeans.cluster_centers_
print(centroids)

# Create Silhouette Plot to Evaluate Clustering

# Must Use Random Samples to Save Memory
data = pd.DataFrame(data = data_minmax,index = range(0,len(data_minmax)),columns = ['Midwest','Northeast','South','West','Revenue_Transformed'])
labels_df = pd.DataFrame(data = labels,index = range(0,len(labels)),columns = ['labels'])
data = pd.concat([data,labels_df],axis = 1)
sample1 = data.sample(n = 10000)
sample1 = sample1.reset_index(drop = True)

sample1_labels = sample1['labels']
sample_with_labels = sample1.copy()
del sample1['labels']
sample_silhouette_values = silhouette_samples(sample1,sample1_labels)


fig, ax1 = plt.subplots(1,1)
fig.set_size_inches(12,7)
ax1.set_xlim([-0.1, 1])
ax1.set_ylim([0, len(sample1) + (k + 1) * 10])

y_lower = 10
for i in range(k):
        # Aggregate the silhouette scores for samples belonging to
        # cluster i, and sort them
        ith_cluster_silhouette_values = sample_silhouette_values[sample1_labels == i]
        ith_cluster_silhouette_values.sort()

        # Set the upper y-bound for cluster i
        size_cluster_i = ith_cluster_silhouette_values.shape[0]
        y_upper = y_lower + size_cluster_i
        
        # Set color formatting 
        color = cm.spectral(float(i)/k)
        ax1.fill_betweenx(np.arange(y_lower, y_upper), 0, ith_cluster_silhouette_values,facecolor=color, edgecolor=color, alpha=0.7)
        
        # Label the silhouette plots with their cluster numbers at the middle
        ax1.text(-0.05, y_lower + 0.5 * size_cluster_i, str(i))

        # Compute the new y_lower for next plot
        y_lower = y_upper + 10  # 10 for the 0 samples


# Set plot title and axis titles
ax1.set_title("Silhouette Plot for 4-Cluster Analysis")
ax1.set_xlabel("Silhouette Coefficient Values")
ax1.set_ylabel("Cluster label")

# Reset tick marks on plot
ax1.set_yticks([])  # Clear the yaxis labels / ticks
ax1.set_xticks([0,0.1, 0.2,0.3, 0.4,0.5, 0.6,0.7, 0.8,0.9, 1])
plt.show()


# Examination and Analysis of Clusters
sample_with_labels['revenue'] = (sample_with_labels['Revenue_Transformed']*(maximum-minimum))+minimum

plt.hist(sample_with_labels['revenue'],bins = 50,range = (0.0,20),log = False)
sample_with_labels['revenue'] = np.exp(sample_with_labels['revenue'])
del sample_with_labels['Revenue_Transformed']

cluster0 = sample_with_labels[(sample_with_labels['labels'] == 3)]
cluster0 = cluster0.reset_index(drop = True)
cluster1 = sample_with_labels[(sample_with_labels['labels'] == 1)]
cluster1 = cluster1.reset_index(drop = True)
cluster2 = sample_with_labels[(sample_with_labels['labels'] == 2)]
cluster2 = cluster2.reset_index(drop = True)
cluster3 = sample_with_labels[(sample_with_labels['labels'] == 0)]
cluster3 = cluster3.reset_index(drop = True)

plt.hist(cluster0['revenue'],bins = 100,range = (0.0,5000),label = '0')
plt.hist(cluster1['revenue'],bins = 100,range = (0.0,5000),label = '1')
plt.hist(cluster2['revenue'],bins = 100,range = (0.0,5000),label = '2')
plt.hist(cluster3['revenue'],bins = 100,range = (0.0,5000),label = '3')
plt.legend(loc='upper right')
plt.xlabel('2015 Revenue per Service Type in Dollars')
plt.ylabel('Frequency')
plt.show()

plt.hist(cluster0['revenue'],bins = 30,range = (5000,10000),label = '0')
plt.hist(cluster1['revenue'],bins = 30,range = (5000,10000),label = '1')
plt.hist(cluster2['revenue'],bins = 30,range = (5000,10000),label = '2')
plt.hist(cluster3['revenue'],bins = 30,range = (5000,10000),label = '3')
plt.legend(loc='upper right')
plt.xlabel('2015 Revenue per Service Type in Dollars')
plt.ylabel('Frequency')
plt.show()

centroids[:,4] = (centroids[:,4]*(maximum-minimum))+minimum
centroids[:,4] = np.exp(centroids[:,4])
print(centroids[:,4])

